package quiz1;

public class doctor {
private:
	
	String name;
String designation;
public:
	doctor(String n,String d){
	name=n;
	designation=d;
}
}
