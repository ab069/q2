package quiz1;
import org.junit.Before

import org.junit.Test
public class wardtest {
@before
ward war= new ward ("ward1","M");
	@Test

}
