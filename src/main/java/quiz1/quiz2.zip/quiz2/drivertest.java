package quiz1;
import java.util.*; 

public class drivertest {
public void main(String []args) {
	System.out.println("hospital management system");
	hospital h1=new 
}
}
